package ar.edu.ort.a2019.c2.tp1.f1.clases;

/**
 * Tipos de operaci�n
 *
 */
public enum TipoOperacion {
	DEPOSITO, EXTRACCION, DEPOSITO_DOLARES, EXTRACCION_DOLARES;
}
