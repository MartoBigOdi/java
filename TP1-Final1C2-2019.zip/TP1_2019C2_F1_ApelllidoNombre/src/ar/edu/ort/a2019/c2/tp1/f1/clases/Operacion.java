package ar.edu.ort.a2019.c2.tp1.f1.clases;

public class Operacion implements Mostrable {

	// TODO COMPLETAR
	/**
	 * Construye una operaci�n.
	 * 
	 * @param tipo  No nulo
	 * @param monto Mayor a 0
	 * @param dia   en el rango correcto.
	 * @param mes   No nulo
	 * @param anio  En el rango correcto (de 2000 a 2019 inclusive)
	 * @throws RuntimeException
	 */
	public Operacion(TipoOperacion tipo, float monto, int dia, Mes mes, int anio) throws RuntimeException {
		// TODO COMPLETAR
//		Ayudita Ojo el orden aqui
	}

	//DESCOMENTAR Y UTILIZAR
//	public void operar() {
//		System.out.println("Operando....");
//		this.mostrar();
//	}


	/**
	 * Devuelve un String con una representaci�n visual de la fecha.
	 * 
	 * @return
	 */
	//TODO Decomentar y utilizar.
//	private String formatearFecha() {
//		return this.dia + " de " + mes.getNombre() + " de " + anio;
//	}

}
