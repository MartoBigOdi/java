/**
 * 
 */
package ar.edu.ort.a2019.c2.tp1.f1.clases;

/**
 *
 */
public class ClienteVIP  {

	public ClienteVIP(int nroCliente, String cuit, String nombreApellido, String email, String celular)
			throws RuntimeException {
		// TODO COMPLETAR
	}
	// TODO COMPLETAR
}
