package ort.edu.ar.clases;

public interface Detallable {
	void verDetalle();
}
