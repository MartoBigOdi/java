package ort.edu.ar.clases;

public class Empresa {

	private String nombre;
	
	public Empresa(String nombre, int cantCamiones) {
	}

	public void agregarCamion(String patente) {
		}

	public void agregarPaquete(Paquete paquete) {
		
	}

	public void verPaquetes() {

	}

	public void camionMayorGanancias() {

	}

}
