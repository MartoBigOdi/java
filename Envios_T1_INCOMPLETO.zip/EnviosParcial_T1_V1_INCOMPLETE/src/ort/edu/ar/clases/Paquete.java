package ort.edu.ar.clases;

public class Paquete {
	
	private double precio;
	private String destino;
	
	public Paquete(String destino) {
		
	}
	
	public abstract void calcularPrecio();

}
