package ort.edu.ar.clases;

public class Camion {
	
	private String patente;

	public Camion(String patente) {
	}

	public void agregarPaquete(Paquete paquete) {
	}

	public double verTotal() {

	}

}
