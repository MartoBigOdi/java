package ar.edu.ort.a2019.c2.tp1.p2.clases;

public class ProductoEstandar  {

	private static final String ETIQUETA = "Producto Estandar";


	/*
	 * TODO COMPLETAR Atributos y m�todos 
	 */


}
