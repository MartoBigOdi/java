package ar.edu.ort.a2019.c2.tp1.p2.clases;

public abstract class Producto {


	private static final String MSG_LA_DESCRIPCI�N_NO_PUEDE_SER_NULO = "La descripci�n no puede ser nulo";
	private static final String MSG_EL_CODIGO_NO_PUEDE_SER_NULO = "El c�digo no puede ser nulo";
	private static final String MSG_EL_NOMBRE_NO_PUEDE_SER_NULO = "El nombre no puede ser nulo";

	
//	TODO Completar M�todos y atributos
}
