package ar.edu.ort.tp1.tp6Ej4.clases;

public enum TipoVehiculo {
	PICKUP, CAMIONETA, CAMION, CAMION_ACOPLADO, CAMION_CON_TOLVA
}
