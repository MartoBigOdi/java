package ar.edu.ort.tp1.tp6Ej5.clases;

public interface Reportable {
    public void reportar();
}
