package ar.edu.ort.a2019.c2.tp1.f1.clases;

public interface Mostrable {
	/**
	 * Muestra la informaci�n pertinente de la clase que lo implementa.
	 */
	//TODO COMPLETAR
}
